Clazz.declarePackage ("javajs.api");
Clazz.load (["java.util.zip.ZipInputStream", "javajs.api.ZInputStream"], "javajs.api.GenericZipInputStream", null, function () {
c$ = Clazz.declareType (javajs.api, "GenericZipInputStream", java.util.zip.ZipInputStream, javajs.api.ZInputStream);
});
