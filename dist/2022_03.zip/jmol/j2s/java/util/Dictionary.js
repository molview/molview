c$=Clazz.declareType(java.util,"Dictionary");
Clazz.makeConstructor(c$,
function(){
});
