Clazz.load(["java.lang.Exception"],"java.lang.CloneNotSupportedException",null,function(){
c$=Clazz.declareType(java.lang,"CloneNotSupportedException",Exception);
});
