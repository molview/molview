Clazz.declareInterface(java.lang,"Cloneable");
