Clazz.load(["java.lang.VirtualMachineError"],"java.lang.OutOfMemoryError",null,function(){
c$=Clazz.declareType(java.lang,"OutOfMemoryError",VirtualMachineError);
});
