Clazz.declareInterface(java.lang,"Runnable");
