Clazz.load(["java.lang.RuntimeException"],"java.lang.reflect.MalformedParameterizedTypeException",null,function(){
c$=Clazz.declareType(java.lang.reflect,"MalformedParameterizedTypeException",RuntimeException);
});
