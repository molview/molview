Clazz.load(["java.io.IOException"],"java.io.UTFDataFormatException",null,function(){
c$=Clazz.declareType(java.io,"UTFDataFormatException",java.io.IOException);
});
