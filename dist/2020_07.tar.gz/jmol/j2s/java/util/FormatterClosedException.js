Clazz.load(["java.lang.IllegalStateException"],"java.util.FormatterClosedException",null,function(){
c$=Clazz.declareType(java.util,"FormatterClosedException",IllegalStateException,java.io.Serializable);
Clazz.makeConstructor(c$,
function(){
Clazz.superConstructor(this,java.util.FormatterClosedException,[]);
});
});
