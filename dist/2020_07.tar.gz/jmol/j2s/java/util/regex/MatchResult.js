Clazz.declarePackage("java.util.regex");
Clazz.declareInterface(java.util.regex,"MatchResult");
