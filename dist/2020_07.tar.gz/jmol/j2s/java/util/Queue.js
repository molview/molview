Clazz.load(["java.util.Collection"],"java.util.Queue",null,function(){
Clazz.declareInterface(java.util,"Queue",java.util.Collection);
});
