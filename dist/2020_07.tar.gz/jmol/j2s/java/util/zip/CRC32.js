Clazz.declarePackage ("java.util.zip");
Clazz.load (["JU.CRC32"], "java.util.zip.CRC32", null, function () {
c$ = Clazz.declareType (java.util.zip, "CRC32", JU.CRC32);
});
