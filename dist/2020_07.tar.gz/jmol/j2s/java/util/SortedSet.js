Clazz.load(["java.util.Set"],"java.util.SortedSet",null,function(){
Clazz.declareInterface(java.util,"SortedSet",java.util.Set);
});
