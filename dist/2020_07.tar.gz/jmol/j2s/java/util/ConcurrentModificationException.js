Clazz.load(["java.lang.RuntimeException"],"java.util.ConcurrentModificationException",null,function(){
c$=Clazz.declareType(java.util,"ConcurrentModificationException",RuntimeException);
Clazz.makeConstructor(c$,
function(){
Clazz.superConstructor(this,java.util.ConcurrentModificationException,[]);
});
});
