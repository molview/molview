Clazz.declarePackage ("java.net");
Clazz.load (["java.io.IOException"], "java.net.UnknownServiceException", null, function () {
c$ = Clazz.declareType (java.net, "UnknownServiceException", java.io.IOException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.net.UnknownServiceException, []);
});
});
