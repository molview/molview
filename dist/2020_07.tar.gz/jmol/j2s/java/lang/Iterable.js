Clazz.declareInterface(java.lang,"Iterable");
