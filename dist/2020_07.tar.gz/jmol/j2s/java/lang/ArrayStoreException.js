Clazz.load(["java.lang.RuntimeException"],"java.lang.ArrayStoreException",null,function(){
c$=Clazz.declareType(java.lang,"ArrayStoreException",RuntimeException);
});
