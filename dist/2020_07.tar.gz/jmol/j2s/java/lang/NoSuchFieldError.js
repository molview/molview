Clazz.load(["java.lang.IncompatibleClassChangeError"],"java.lang.NoSuchFieldError",null,function(){
c$=Clazz.declareType(java.lang,"NoSuchFieldError",IncompatibleClassChangeError);
});
