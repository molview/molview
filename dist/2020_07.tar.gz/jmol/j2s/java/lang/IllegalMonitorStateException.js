Clazz.load(["java.lang.RuntimeException"],"java.lang.IllegalMonitorStateException",null,function(){
c$=Clazz.declareType(java.lang,"IllegalMonitorStateException",RuntimeException);
});
