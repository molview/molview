Clazz.load(["java.lang.Exception"],"java.lang.InterruptedException",null,function(){
c$=Clazz.declareType(java.lang,"InterruptedException",Exception);
});
