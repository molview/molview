Clazz.load(["java.lang.IllegalArgumentException"],"java.lang.NumberFormatException",null,function(){
c$=Clazz.declareType(java.lang,"NumberFormatException",IllegalArgumentException);
});
