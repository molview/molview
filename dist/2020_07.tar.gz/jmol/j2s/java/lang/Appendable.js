Clazz.declareInterface(java.lang,"Appendable");
