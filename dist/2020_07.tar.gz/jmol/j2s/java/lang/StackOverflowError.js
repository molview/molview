Clazz.load(["java.lang.VirtualMachineError"],"java.lang.StackOverflowError",null,function(){
c$=Clazz.declareType(java.lang,"StackOverflowError",VirtualMachineError);
});
