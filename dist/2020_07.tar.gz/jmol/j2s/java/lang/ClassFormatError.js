Clazz.load(["java.lang.LinkageError"],"java.lang.ClassFormatError",null,function(){
c$=Clazz.declareType(java.lang,"ClassFormatError",LinkageError);
});
