Clazz.declareInterface(java.lang,"Comparable");
