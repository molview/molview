Clazz.load(["java.lang.Error"],"java.lang.LinkageError",null,function(){
c$=Clazz.declareType(java.lang,"LinkageError",Error);
});
