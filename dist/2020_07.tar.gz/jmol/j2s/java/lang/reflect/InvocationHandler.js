Clazz.declareInterface(java.lang.reflect,"InvocationHandler");
