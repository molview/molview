Clazz.load(["java.io.IOException"],"java.io.EOFException",null,function(){
c$=Clazz.declareType(java.io,"EOFException",java.io.IOException);
});
