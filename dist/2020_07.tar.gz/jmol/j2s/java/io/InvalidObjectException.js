Clazz.load(["java.io.ObjectStreamException"],"java.io.InvalidObjectException",null,function(){
c$=Clazz.declareType(java.io,"InvalidObjectException",java.io.ObjectStreamException);
});
