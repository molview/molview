Clazz.load(["java.io.ObjectStreamException"],"java.io.StreamCorruptedException",null,function(){
c$=Clazz.declareType(java.io,"StreamCorruptedException",java.io.ObjectStreamException);
});
