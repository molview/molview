Clazz.declarePackage ("JS");
Clazz.declareInterface (JS, "TableCellRenderer");
