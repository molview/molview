Clazz.declarePackage ("javajs.api.js");
Clazz.declareInterface (javajs.api.js, "J2SObjectInterface");
