Clazz.declarePackage ("J.translation");
c$ = Clazz.declareType (J.translation, "PO");
