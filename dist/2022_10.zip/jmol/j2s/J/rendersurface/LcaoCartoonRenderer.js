Clazz.declarePackage ("J.rendersurface");
Clazz.load (["J.rendersurface.IsosurfaceRenderer"], "J.rendersurface.LcaoCartoonRenderer", null, function () {
c$ = Clazz.declareType (J.rendersurface, "LcaoCartoonRenderer", J.rendersurface.IsosurfaceRenderer);
});
