Clazz.declarePackage ("J.api.js");
Clazz.load (["javajs.api.js.J2SObjectInterface"], "J.api.js.JmolToJSmolInterface", null, function () {
Clazz.declareInterface (J.api.js, "JmolToJSmolInterface", javajs.api.js.J2SObjectInterface);
});
