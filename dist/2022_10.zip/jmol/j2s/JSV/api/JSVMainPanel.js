Clazz.declarePackage ("JSV.api");
Clazz.load (["JSV.api.JSVViewPanel"], "JSV.api.JSVMainPanel", null, function () {
Clazz.declareInterface (JSV.api, "JSVMainPanel", JSV.api.JSVViewPanel);
});
